# Todo List - ReactJS

Well this is a basic project where we developed a todo-list using ReactJS with TypeScript . The main functions are: create task, mark it as completed and finally we have the delete functionality. It's the first challenge accomplished by rocketseat-ignite(track-reactJS)

## Some pictures of the project
![Captura de Ecrã (49)](https://user-images.githubusercontent.com/89365650/189788182-7d45f0e8-da91-4ff7-bf7a-02f04ccbdc0f.png)

![Captura de Ecrã (50)](https://user-images.githubusercontent.com/89365650/189788395-ba9008c9-7ba7-4cf6-90e7-2c9951056d38.png)
